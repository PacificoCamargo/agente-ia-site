# Agente.IA Site

Este é o site estático da **Agente.IA** pronto para publicação via GitHub Pages.

## Publicar
1. No GitHub, crie o repositório `agente-ia-site` (público).
2. Clique em **Add File** → **Upload files**
3. Arraste e solte todo o conteúdo desta pasta.
4. Garanta que `index.html` está na raiz.
5. Vá em **Settings → Pages → Deploy from a branch → main (root)**.
6. Acesse: https://seuusuario.github.io/agente-ia-site
